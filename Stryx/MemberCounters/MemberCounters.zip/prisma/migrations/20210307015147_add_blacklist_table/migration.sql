-- CreateTable
CREATE TABLE "blacklist" (
    "id" SERIAL NOT NULL,
    "userId" TEXT NOT NULL,

    PRIMARY KEY ("id")
);
