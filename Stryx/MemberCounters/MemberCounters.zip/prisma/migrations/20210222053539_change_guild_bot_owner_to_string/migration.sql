-- AlterTable
ALTER TABLE "guilds" ALTER COLUMN "botOwner" SET DATA TYPE TEXT;
