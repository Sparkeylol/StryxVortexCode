-- AlterTable
ALTER TABLE "tickets" ADD COLUMN     "status" TEXT NOT NULL DEFAULT E'OPEN';
