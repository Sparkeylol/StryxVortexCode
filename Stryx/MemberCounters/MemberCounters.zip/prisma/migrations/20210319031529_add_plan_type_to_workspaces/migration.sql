-- AlterTable
ALTER TABLE "workspace" ADD COLUMN     "plan_type" INTEGER NOT NULL DEFAULT 1;
