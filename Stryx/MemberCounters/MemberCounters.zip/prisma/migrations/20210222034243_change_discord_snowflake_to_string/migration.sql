-- AlterTable
ALTER TABLE "customer_data" ALTER COLUMN "user_id" SET DATA TYPE TEXT;

-- AlterTable
ALTER TABLE "guilds" ALTER COLUMN "guildId" SET DATA TYPE TEXT;
