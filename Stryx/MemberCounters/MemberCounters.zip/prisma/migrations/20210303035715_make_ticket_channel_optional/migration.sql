-- AlterTable
ALTER TABLE "tickets" ALTER COLUMN "channel" DROP NOT NULL;
