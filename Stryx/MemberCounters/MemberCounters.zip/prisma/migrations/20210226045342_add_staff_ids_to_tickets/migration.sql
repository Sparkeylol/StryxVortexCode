-- AlterTable
ALTER TABLE "tickets" ADD COLUMN     "staffIds" TEXT[];
