-- AlterTable
ALTER TABLE "blacklist" ALTER COLUMN "expirationDate" SET DATA TYPE TEXT,
ALTER COLUMN "dateIssued" SET DATA TYPE TEXT;
