-- AlterTable
ALTER TABLE "customer_data" ADD COLUMN     "stripe_customer_id" TEXT;
