-- AlterTable
ALTER TABLE "guilds" ALTER COLUMN "region" SET DEFAULT E'LOCAL';
