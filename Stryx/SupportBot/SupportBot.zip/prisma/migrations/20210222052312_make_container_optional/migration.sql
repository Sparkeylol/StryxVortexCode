-- AlterTable
ALTER TABLE "guilds" ALTER COLUMN "container" DROP NOT NULL;
