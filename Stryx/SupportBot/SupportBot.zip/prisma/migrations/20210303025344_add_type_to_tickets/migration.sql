-- AlterTable
ALTER TABLE "tickets" ADD COLUMN     "type" TEXT NOT NULL DEFAULT E'ticket';
